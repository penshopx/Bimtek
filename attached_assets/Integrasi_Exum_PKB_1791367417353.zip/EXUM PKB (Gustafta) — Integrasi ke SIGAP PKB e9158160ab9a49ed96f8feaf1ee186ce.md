# EXUM PKB (Gustafta) — Integrasi ke SIGAP PKB

<aside>
🔗

Aplikasi berjalan: [exum-pkb.replit.app](https://exum-pkb.replit.app/) · Rujukan: Permen PUPR 12/2021, SE DJBK 214/SE/Dk/2022 (format Executive Summary), SK DJBK 114/2024 (kompetensi jabker). Posisi: EXUM PKB menjadi **mesin penyusun Executive Summary** di dalam SIGAP PKB. Aplikasi menyiapkan, pihak berwenang menilai.

</aside>

## 1. Peran dalam SIGAP PKB

| Komponen SIGAP | Dilayani oleh EXUM PKB | Data di Notion |
| --- | --- | --- |
| Coach Executive Summary | Sesi wawancara 6 fase → outline → draf EXUM | [Executive Summary PKB](https://app.notion.com/p/f874143025ea4637b14f40b135890f7a?pvs=21) (Mode EXUM, Sesi EXUM PKB) |
| Pelacak SKPK | Jurnal Kegiatan PKB + bukti + estimasi kredit | Executive Summary PKB (Estimasi Angka Kredit, Cek Aturan) |
| Kurator PKB | Studio Kompetensi (gap) + Marketplace/video | Katalog Jabatan |
| Pembinaan oleh asosiasi | Dashboard asosiasi / lembaga diklat / instruktur | [Kegiatan](https://app.notion.com/p/e78bd8580d174928937d784b0cbb5cb3?pvs=21) (Bentuk: Coaching Executive Summary) |

## 2. Format wajib Executive Summary (SE DJBK 214/SE/Dk/2022)

Judul: *Ringkasan Eksekutif (Executive Summary) Pembelajaran Sehubungan dengan Penugasan Kerja* — Judul Pembelajaran — Oleh (tenaga ahli).

1. **Rincian Penugasan Kerja** — nama pengguna langsung/pemberi kerja, penempatan (proyek/manajerial), nama paket pekerjaan, alamat penugasan, waktu pelaksanaan, posisi penugasan, judul pembelajaran.
2. **Uraian Tugas Pekerjaan** — ringkasan pokok pekerjaan yang dilakukan.
3. **Target Pengembangan Keahlian** — keahlian/kemampuan yang hendak dicapai.
4. **Pembelajaran Sehubungan dengan Penugasan Kerja** — dijabarkan per sub bagian, masing-masing berisi substansi yang ditemui dan dipelajari.

Template Notion "Template Executive Summary PKB" sudah mengikuti struktur ini. Generator EXUM wajib memakai urutan & judul bab yang sama.

## 3. Kerangka wawancara (Gustafta Exum Interviewer v2.1)

- Mode A — Pengalaman Kerja (persona Pak Budi, berbasis ESIMPAN & uraian jabatan) → unsur *Pembelajaran terkait Penugasan Kerja*.
- Mode B — Hasil Belajar (persona Bu Rina: webinar, modul, buku, video) → unsur *Pembelajaran Mandiri*.
- Hybrid — pembelajaran yang dibuktikan lewat penerapan.
- Aturan: maks. 2 pertanyaan per respons · STAR + Impact + Refleksi · selalu minta angka/contoh konkret · kaitkan ke kompetensi jabker (SK DJBK 114/2024).
- 6 fase: Profiling → Konteks → Wawancara Inti → Bukti & Data → Sintesis → Selesai.
- Bank pertanyaan saat ini: Ahli Muda/Madya Manajemen Konstruksi, Ahli Muda Teknik Sipil, Ahli Muda K3 Konstruksi, Ahli Muda Quantity Surveyor (36–45 soal/jabker, 5 bagian: refleksi, koneksi jabker, aplikasi, simulasi/kasus, dampak).

## 4. Pemetaan Bab SE ↔ Fase wawancara

| Bab SE 214 | Fase EXUM | Sumber data |
| --- | --- | --- |
| I. Rincian Penugasan Kerja | Profiling + Konteks | Profil, kontrak/surat referensi, Otak Proyek |
| II. Uraian Tugas Pekerjaan | Konteks + Wawancara Inti (Task/Action) | Uraian jabatan, ESIMPAN |
| III. Target Pengembangan Keahlian | Wawancara Inti (koneksi jabker) | Studio Kompetensi — gap unit SKK |
| IV. Pembelajaran sehubungan Penugasan | Wawancara Inti + Bukti & Data + Sintesis | Jawaban STAR/Impact/Refleksi + lampiran |

## 5. Catatan penyelarasan (perlu diperbaiki di aplikasi)

- [ ]  System prompt menyebut EXUM "bernilai 25 SKPK". Ubah menjadi "nilai dasar maks. 25 SKPK per produk; nilai akhir ditetapkan asesor" agar tidak menjanjikan kredit.
- [ ]  Target "10–15 halaman" adalah standar internal, bukan ketentuan SE 214. Tandai sebagai rekomendasi.
- [ ]  Contoh EXUM Mode B (8 bab) belum mengikuti 4 bab SE 214. Untuk penugasan kerja, keluaran wajib 4 bab SE; bab tambahan (dampak, tantangan, RTL) masuk sebagai sub bagian Bab IV atau lampiran.
- [ ]  Ingatkan batas komposisi: total pendidikan nonformal (termasuk EXUM) ≤25% Nilai Kredit.
- [ ]  Penugasan kerja wajib melampirkan kontrak kerja / surat referensi.
- [ ]  Ekspor EXUM menyertakan field pencatatan SIJK (lokasi, tahun, periode, tanggal, durasi, peran — Pasal 19 ayat 3).
- [ ]  Pertahankan batas dari Panduan Operasional: status "Terverifikasi" hanya internal, tanpa integrasi pemerintah otomatis, tanpa peran ASKOM PKB.

## 6. Integrasi ke Hermes × MultiClaw

- Agen **Coach Executive Summary** memanggil EXUM PKB (sesi baru per kegiatan), lalu menyimpan tautan sesi & draf ke DB Executive Summary PKB.
- Agen **Pelacak SKPK** membaca Estimasi Angka Kredit dan memberi peringatan komposisi.
- Agen **Kurator PKB** memakai gap Studio Kompetensi untuk merekomendasikan materi Marketplace.
- Semua keluaran AI dipisah dari fakta pengguna dan keputusan reviewer (audit trail).