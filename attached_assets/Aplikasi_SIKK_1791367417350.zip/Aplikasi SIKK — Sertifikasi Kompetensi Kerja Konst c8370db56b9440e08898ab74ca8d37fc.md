# Aplikasi SIKK — Sertifikasi Kompetensi Kerja Konstruksi (model SKTTK)

> Aplikasi pengelolaan sertifikasi tenaga kerja konstruksi dengan alur seperti SKTTK (ketenagalistrikan), tetapi mengikuti ekosistem jasa konstruksi: **Tenaga Kerja → LSP → Asesor/TUK → LPJK (SIJK) → SKK**. Terhubung ke Katalog Jabatan, Asosiasi, BUJK, dan modul PKB/PUB di blueprint induk.
> 

## 1. Padanan SKTTK → Jasa Konstruksi

| Aspek | SKTTK (Ketenagalistrikan) | SIKK (Jasa Konstruksi) |
| --- | --- | --- |
| Sertifikat | SKTTK | SKK Konstruksi |
| Lembaga sertifikasi | LSK Ketenagalistrikan | LSP terlisensi BNSP & tercatat LPJK |
| Regulator/registri | Ditjen Ketenagalistrikan | Ditjen Bina Konstruksi / LPJK (SIJK) |
| Acuan kompetensi | SKKNI Ketenagalistrikan | SKKNI/SKKK jabatan kerja konstruksi (Katalog Jabatan) |
| Pemeliharaan kompetensi | Perpanjangan sertifikat | Perpanjangan SKK + PKB (SKPK) untuk jenjang Ahli |
| Pengguna di perusahaan | Badan usaha ketenagalistrikan | BUJK (tenaga kerja utusan/penanggung jawab) |

## 2. Modul Aplikasi

1. **Registrasi & Profil Tenaga Kerja** — NIK, pendidikan, pengalaman, Asosiasi (No. KTA), BUJK, unggah dokumen.
2. **Permohonan Sertifikasi** — Baru / Perpanjangan / Kenaikan Jenjang / Tambah Subklasifikasi; pilih jabatan dari Katalog Jabatan.
3. **Verifikasi Dokumen** — oleh admin LSP (kelengkapan ijazah, pengalaman, logbook, bukti PKB untuk perpanjangan).
4. **Asesmen Mandiri (APL-01/APL-02)** — portofolio per unit kompetensi; disiapkan dengan bantuan agen AI (modul latihan SKK).
5. **Penjadwalan Uji & TUK** — jadwal, TUK, metode (luring/daring), penugasan asesor, kuota.
6. **Uji Kompetensi & Rekomendasi** — hasil Kompeten / Belum Kompeten per asesi.
7. **Pencatatan & Penerbitan SKK** — nomor registrasi, tanggal terbit, masa berlaku, file sertifikat, tautan verifikasi.
8. **Verifikasi Publik (QR)** — cek keabsahan SKK oleh pengguna jasa/BUJK.
9. **Pengingat Masa Berlaku & PKB** — notifikasi 180 hari sebelum kedaluwarsa; tautkan capaian SKPK.
10. **Dasbor** — statistik pemohon per klasifikasi/jenjang, tingkat kelulusan, SKK aktif vs kedaluwarsa.

## 3. Alur Proses

```mermaid
flowchart LR
  A[Registrasi Tenaga Kerja] --> B[Permohonan Sertifikasi]
  B --> C[Verifikasi Dokumen LSP]
  C -->|Lengkap| D[Asesmen Mandiri APL]
  C -->|Kurang| B
  D --> E[Jadwal Uji & TUK]
  E --> F[Uji Kompetensi oleh Asesor]
  F -->|Kompeten| G[Pencatatan LPJK / SIJK]
  F -->|Belum Kompeten| D
  G --> H[SKK Terbit + QR Verifikasi]
  H --> I[Pengingat Masa Berlaku & PKB]
  I --> B
```

## 4. Peran Pengguna

| Peran | Hak akses utama |
| --- | --- |
| Tenaga Kerja (Asesi) | Profil, permohonan, asesmen mandiri, unduh SKK |
| Admin BUJK | Mendaftarkan tenaga kerja utusan, memantau SKK karyawan |
| Admin Asosiasi | Validasi keanggotaan (KTA), rekap PKB anggota |
| Admin LSP | Verifikasi dokumen, jadwal uji, penugasan asesor |
| Asesor | Penilaian & rekomendasi |
| Verifikator LPJK | Pencatatan & penerbitan nomor registrasi |
| Publik | Verifikasi keabsahan SKK |

## 5. Integrasi Agen AI (Hermes × MultiClaw)

- **Agen Pendaftaran** — memandu isian profil & cek kelengkapan dokumen otomatis.
- **Agen Kesesuaian Jabatan** — merekomendasikan jabatan/jenjang dari pendidikan + pengalaman (berdasarkan Katalog Jabatan).
- **Agen Portofolio APL** — membantu menyusun bukti per unit kompetensi.
- **Agen Latihan Uji** — simulasi soal & wawancara per SKKNI.
- **Agen Pengingat** — memantau masa berlaku SKK & target SKPK.

## 6. Basis Data Aplikasi

Database di bawah ini adalah inti aplikasi (MVP di Notion; dapat dimigrasikan ke web/mobile app).

[Tenaga Kerja Konstruksi](Tenaga%20Kerja%20Konstruksi%2073cd31a0c1474020864145650bacb621.csv)

[LSP & TUK](LSP%20&%20TUK%209e0c2ce4f40f49818214bf20b2b530d4.csv)

[Asesor](Asesor%20089beffbddd34a7f8f432e3769f48c1a.csv)

[Jadwal Uji Kompetensi](Jadwal%20Uji%20Kompetensi%20cd4be1c851bc4695b82f303fb29e1b9e.csv)

[Sertifikat SKK](Sertifikat%20SKK%20958a496fd6b247fe97a8ab397d365faf.csv)

[Permohonan Sertifikasi](Permohonan%20Sertifikasi%20e155a4d7653849ebb4260a46949d1a0a.csv)