# Blueprint SIGAP Kompetensi — SIGAP UJK, SIGAP PKB & SIGAP PUB (Agentic AI)

<aside>
🎯

Platform pembinaan tenaga kerja konstruksi sepanjang karier berbasis Agentic AI (Hermes × MultiClaw-OpenClaw). Payung: **SIGAP Kompetensi by Gustafta** (Pilar 2). Isinya tiga aplikasi di atas satu mesin bersama: **SIGAP UJK** (persiapan uji kompetensi), **SIGAP PKB** (Permen PUPR 12/2021), dan **SIGAP PUB** (Permen PUPR 7/2024). Riwayat setiap orang tercatat di **Paspor Kompetensi SIGAP** (Memori Profesional di Ruang Simpan). Setiap kegiatan wajib memiliki **KAK** dan **Laporan Kegiatan** yang terdokumentasi.

</aside>

## 1. Modul & Sasaran

| Modul | Sasaran | Dasar | Fungsi Utama |
| --- | --- | --- | --- |
| **SIGAP UJK** (Uji Kompetensi) | Perorangan, semua jenjang (KKNI 1–9) | SKKNI / SKK Khusus per jabatan | Diagnostik, tutor per KUK, tryout, simulasi asesor, review portofolio, laporan kesiapan |
| **SIGAP PKB** | Perorangan kualifikasi **Ahli** (jenjang 7–9) | Permen PUPR 12/2021 | Kegiatan pembelajaran, coaching executive summary, pelacak SKPK perpanjangan SKK |
| **SIGAP PUB** | **BUJK** melalui Asosiasi Badan Usaha | Permen PUPR 7/2024 | PUB umum & khusus (pembelajaran tekstual, interaktif jarak jauh, bimtek, pendampingan), evaluasi kinerja, laporan |

### Aturan kunci PKB (Permen PUPR 12/2021)

- Target Nilai Kredit untuk perpanjangan SKK: **≥100 SKPK** (jenjang 7), **≥150 SKPK** (jenjang 8), **≥200 SKPK** (jenjang 9).
- Komposisi Nilai Kredit (Pasal 20): kegiatan utama ≥75% · penunjang ≤25% · pendidikan nonformal ≤25% · terverifikasi ≥60% (tidak terverifikasi ≤40%) · khusus ≥60% (umum ≤40%).
- Angka Kredit = nilai dasar × bobot jenis × sifat × metode × tingkat (Pasal 24 ayat 4). Bobot jenis: terverifikasi 1 · tidak terverifikasi dapat divalidasi 0,8 · tidak dapat divalidasi 0,25. Sifat: khusus 1 · umum 0,8. Metode: luring 1 · daring 0,8. Tingkat: nasional 1 · internasional di dalam negeri 2 · luar negeri 3.
- Pengajuan kegiatan oleh penyelenggara ≥4 hari kerja sebelum pelaksanaan dengan KAK, SK panitia, CV narasumber (Pasal 13). Laporan kegiatan maks. 14 hari setelah kegiatan (Pasal 15 ayat 4).
- Penilaian oleh asesor → LPJK melalui **Asosiasi Profesi terakreditasi** → dicatat di SIJK. Aplikasi **tidak menerbitkan SKPK sendiri**; wajib bermitra dengan Asosiasi Profesi.
- Executive summary / extended abstract menjadi bukti kegiatan. Agen hanya membimbing (kerangka, review), bukan menulis atas nama peserta.

### Executive Summary sebagai kegiatan PKB

| Unsur kegiatan | Nilai dasar | Berkas kelengkapan |
| --- | --- | --- |
| Pembelajaran Mandiri (nonformal, mandiri) | maks. 25 SKPK / produk | Executive summary / extended abstract (+ pertanyaan & jawaban pemahaman) |
| Pembelajaran terkait Penugasan Kerja (nonformal) | maks. 25 SKPK / produk | Executive summary + kontrak kerja / surat referensi |
| Peserta Pertemuan Profesi | 5 SKPK (≤3 hari, +1/hari berikutnya) | Sertifikat + summary |
| Paparan & Laporan Teknis Internal | PJ 10 · pemapar 7 · anggota 5 | Executive summary / laporan teknis |
| Paparan dalam Pertemuan Teknis | 5 SKPK × bobot tingkat | Executive summary + bukti paparan |
- Alur SIGAP PKB: susun (Template Executive Summary PKB) → review Coach AI (kerangka, kelengkapan, relevansi subklasifikasi) → revisi → catat di buku catatan elektronik SIJK (lokasi, tahun, periode, tanggal, durasi, peran, lampiran — Pasal 19 ayat 3) → dinilai asesor LSP saat perpanjangan SKK (Pasal 23, 27).
- Kegiatan pembinaan oleh asosiasi dicatat di DB Kegiatan dengan Bentuk Kegiatan "Coaching Executive Summary"; produk per peserta dicatat di DB Executive Summary PKB.
- Batas: total pendidikan nonformal (termasuk executive summary mandiri) ≤25% Nilai Kredit. Angka kredit di sistem hanya estimasi; penetapan oleh asesor/LPJK.

### Aturan kunci PUB (Permen PUPR 7/2024)

- PUB umum: seluruh anggota Asosiasi Badan Usaha, ≥1×/tahun (workshop, sosialisasi).
- PUB khusus: seluruh BUJK kecil, serta BUJK menengah/besar/spesialis berdasarkan nilai kinerja tahunan.
- Modul BUJK kecil: dasar manajemen proyek, administrasi kontrak, manajemen keuangan, SMKK, SMAP.
- Modul BUJK menengah/besar/spesialis: manajemen proyek, kemampuan keuangan, organisasi, operasi, teknologi, SDM, SMAP.
- Sasaran peserta: PJBU, PJTBU, PJSKBU, GS, kepala proyek, kepala pengawas lapangan, site engineer, team leader, quantity/quality engineer, HSE engineer.
- Laporan kegiatan maks. **14 hari kerja** via SIJK; evaluasi kinerja sebelum–sesudah PUB khusus pada **Juni tahun berikutnya**.

## 1A. Alur Kesiapan Berbasis Bukti (mesin bersama)

SIGAP UJK tidak berhenti pada "materi selesai" atau "nilai tryout". Kesiapan peserta dibangun bertahap dan harus dibuktikan.

```mermaid
flowchart LR
  A[1. Petakan<br/>asesmen mandiri per unit] --> B[2. Pelajari<br/>materi per elemen & KUK]
  B --> C[3. Latih<br/>studi kasus & soal]
  C --> D[4. Kumpulkan Bukti<br/>portofolio & hasil kerja]
  D --> E[5. Uji Coba<br/>tryout + simulasi wawancara asesor]
  E --> F{6. Gerbang Wajib K3}
  F -- lulus --> G[7. Rekomendasi<br/>Siap Diajukan]
  F -- gagal --> R[Rencana Perbaikan<br/>+ uji ulang]
  E -- unit lemah --> R
  R --> B
```

| Prinsip | Penerapan di SIGAP |
| --- | --- |
| **Gerbang Wajib K3** | Unit/KUK yang menyangkut keselamatan (SMKK, pekerjaan berisiko tinggi) ditandai *wajib lulus*. Jika gagal, status tetap *Belum Siap* walaupun rata-rata nilai tinggi. |
| **Bukti dulu, baru siap** | Setiap unit butuh bukti yang memenuhi prinsip asesmen: **Valid, Asli, Terkini, Memadai**. Bukti ditautkan ke KUK dan disimpan di Ruang Simpan. |
| **Gap → Rencana Perbaikan** | Kelemahan menghasilkan daftar tugas belajar, latihan, dan bukti tambahan, lalu uji ulang. |
| **Riwayat utuh** | Paspor Kompetensi SIGAP menyimpan semua percobaan, gap, dan perkembangan; tidak ada yang dihapus. Riwayat ini juga menjadi bahan SIGAP PKB. |
| **Batas keputusan** | Status aplikasi: *Belum Siap / Perlu Perbaikan / Siap Diajukan*. Keputusan **Kompeten / Belum Kompeten** tetap milik asesor LSP. |

### Status Kesiapan (aturan deterministik)

| Status | Syarat |
| --- | --- |
| Belum Siap | Ada unit belum dipelajari, atau ada Gerbang Wajib K3 gagal |
| Perlu Perbaikan | Semua unit sudah dilatih, tetapi ada unit di bawah ambang atau bukti belum memadai |
| Siap Diajukan | Semua unit ≥ ambang, semua Gerbang Wajib K3 lulus, bukti tiap unit memadai, simulasi asesor lulus |

## 2. Arsitektur Agentic AI

- **Hermes (orkestrator):** profil & memori peserta/BUJK, rencana belajar, routing ke agen, kontrol mutu.
- **MultiClaw / OpenClaw (agen spesialis):** setiap agen berizin terbatas dan hanya menjawab dari basis data standar (Jabatan → Standar → Unit → Elemen → KUK). Tanpa rujukan = tanpa jawaban.

| Kelompok | Agen | Tugas |
| --- | --- | --- |
| SIGAP UJK | Diagnostik | Asesmen mandiri awal, peta gap per unit |
| SIGAP UJK | Tutor Unit Kompetensi | Materi per elemen & KUK dengan rujukan |
| SIGAP UJK | Bank Soal & Tryout | Soal ber-tag KUK, penilaian, pembahasan |
| SIGAP UJK | Simulasi Asesor | Wawancara sesuai jenjang (Ahli / Teknisi / Operator) |
| SIGAP UJK | Reviewer Portofolio & Praktik | Cek bukti, gambar kerja, tugas praktik |
| SIGAP UJK | Analitik Kesiapan | Status kesiapan per unit & keseluruhan (bukan keputusan K/BK), rencana perbaikan |
| SIGAP PKB | Kurator PKB | Rekomendasi kegiatan sesuai komposisi kredit |
| SIGAP PKB | Coach Executive Summary | Kerangka & review (bukan ghostwriting) |
| SIGAP PKB | Pelacak SKPK | Catat kegiatan & bukti, estimasi kredit, pengingat masa berlaku SKK |
| SIGAP PUB | Tutor PUB | Materi & kuis per modul sesuai kualifikasi BUJK |
| SIGAP PUB | Analis Kinerja BUJK | Pemetaan kelemahan & pemilihan modul |
| Penyelenggaraan | Perancang Kegiatan | Draf KAK dari template |
| Penyelenggaraan | Dokumentasi | Absensi, log time stamp, media |
| Penyelenggaraan | Statistik & Evaluasi | Kehadiran, pre/post-test, n-gain, survei |
| Penyelenggaraan | Pelaporan | Laporan kegiatan + lampiran, berkas siap unggah SIJK |
| Penyelenggaraan | Sertifikat & Verifikasi | Sertifikat ber-QR/hash |
| Layanan | Administrasi & Validasi | Validasi KTA/NIB/SKK, persyaratan, pengingat |

## 3. Siklus Setiap Kegiatan

**KAK → Persetujuan → Pelaksanaan (dokumentasi otomatis) → Laporan Kegiatan → Review manusia → Arsip / unggah SIJK**

- **KAK:** latar belakang & dasar hukum, tujuan & sasaran, ruang lingkup & materi (KUK / modul PUB), metode, narasumber & agen, jadwal & tempat/platform, keluaran & indikator keberhasilan, anggaran, rencana evaluasi & pelaporan.
- **Dokumentasi otomatis:** absensi (check-in/out, durasi, OTP/foto), log time stamp append-only, data peserta, pre/post-test, statistik, survei evaluasi penyelenggaraan, produk peserta, media, sertifikat.
- **Laporan:** struktur minimal PUB (asosiasi, sifat & bentuk, tempat & tanggal, daftar peserta, materi, dokumentasi, rekomendasi & RTL) + target vs capaian + lampiran; untuk PKB disertai sertifikat & executive summary per peserta.

## 4. Formulir Pendaftaran Peserta PKB / PUB

- **A. Jenis kegiatan:** Uji SKK / PKB / PUB Umum / PUB Khusus.
- **B. Data peserta:** nama, NIK (tersamar), email, HP/WA, no. registrasi SKK & masa berlaku, jabatan & jenjang.
- **C. Asosiasi asal:** jenis asosiasi, nama asosiasi asal, **nomor KTA** & masa berlaku, unggah KTA.
- **D. Status kepesertaan:** Mandiri / **Utusan BUJK** → nama BUJK, NIB, kualifikasi BUJK, Asosiasi Badan Usaha & no. KTA BUJK, jabatan di BUJK, surat tugas, PIC perusahaan.
- **E. Persetujuan:** pengolahan data pribadi (UU PDP) & pernyataan kebenaran data.

| Kegiatan | Wajib diisi |
| --- | --- |
| PKB | Asosiasi Profesi + nomor KTA (data BUJK opsional) |
| PUB | Data BUJK, Asosiasi Badan Usaha, KTA BUJK, jabatan sasaran PUB, surat tugas |

## 5. Tata Kelola & Risiko

- Sumber jawaban wajib dari dokumen standar/regulasi; label **Standar Sementara** untuk jabatan berbasis skema LPJK/RSKKNI.
- Posisi aplikasi: alat **persiapan & pembinaan**, bukan pengganti uji resmi LSP/BNSP maupun penilaian SKPK oleh asesor.
- Log tidak dapat diedit; koreksi dicatat sebagai entri baru beserta alasan.
- UU PDP: persetujuan, NIK tersamar, akses per peran, retensi data.
- KAK dan laporan disusun agen, **ditandatangani & dikirim oleh penyelenggara**.

## 6. Roadmap

| Fase | Cakupan |
| --- | --- |
| 1 | SIGAP UJK: Arsitektur (8 jenjang) + Sipil–Gedung (71 jenjang); lapisan KAK & laporan |
| 2 | Seluruh Sipil dengan SKKNI final; SIGAP PKB bersama 1 Asosiasi Profesi |
| 3 | SIGAP PUB untuk BUJK kecil bersama 1 Asosiasi Badan Usaha, lalu menengah/besar/spesialis |
| 4 | Klasifikasi Mekanikal & Tata Lingkungan; WhatsApp/suara; dashboard perusahaan |

## 7. Database Inti

Katalog Jabatan · Asosiasi · BUJK · Kegiatan (dengan template KAK & Laporan) · Peserta (formulir pendaftaran) · Absensi & Log.

[Katalog Jabatan](Katalog%20Jabatan%20640a9b4d908243bdaeebe573ef72288e.csv)

[Asosiasi](Asosiasi%20685e85c71ab84d29a0cb6862e9ccfd63.csv)

[BUJK](BUJK%20ec496dfaef924d52837282f3d77f78c2.csv)

[Kegiatan](Kegiatan%20e78bd8580d174928937d784b0cbb5cb3.csv)

[Peserta](Peserta%20c6c527db5dd442a2a7264f3271799ab3.csv)

[Absensi & Log Aktivitas](Absensi%20&%20Log%20Aktivitas%20745fd71184be4e7c9f017878e2de37a8.csv)

[Spesifikasi SIGAP UJK + Prompt Replit (Mesin Bersama SIGAP Kompetensi)](https://app.notion.com/p/Spesifikasi-SIGAP-UJK-Prompt-Replit-Mesin-Bersama-SIGAP-Kompetensi-537bfbbba37a449786f755f07d8577be?pvs=21)

[Aplikasi SIKK — Sertifikasi Kompetensi Kerja Konstruksi (model SKTTK)](https://app.notion.com/p/Aplikasi-SIKK-Sertifikasi-Kompetensi-Kerja-Konstruksi-model-SKTTK-c8370db56b9440e08898ab74ca8d37fc?pvs=21)

[Executive Summary PKB](Executive%20Summary%20PKB%20f874143025ea4637b14f40b135890f7a.csv)

[EXUM PKB (Gustafta) — Integrasi ke SIGAP PKB](https://app.notion.com/p/EXUM-PKB-Gustafta-Integrasi-ke-SIGAP-PKB-e9158160ab9a49ed96f8feaf1ee186ce?pvs=21)