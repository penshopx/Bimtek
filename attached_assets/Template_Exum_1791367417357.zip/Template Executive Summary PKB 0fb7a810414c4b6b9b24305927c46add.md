# Template Executive Summary PKB

Cek Aturan: ⚠️ Executive summary belum diunggah
Estimasi Angka Kredit: 0
Status: Draft

<aside>
⚖️

Format mengacu **SE Dirjen Bina Konstruksi No. 214/SE/Dk/2022** (Bab VII Format Executive Summary) dan Permen PUPR 12/2021. Nilai dasar maks. 25 SKPK per produk; penetapan oleh asesor. Disusun sendiri oleh tenaga ahli — EXUM Interviewer / Coach AI hanya menggali fakta & merapikan, tidak mengarang proyek, angka, atau capaian.

</aside>

**RINGKASAN EKSEKUTIF**

**(*EXECUTIVE SUMMARY*)**

**PEMBELAJARAN SEHUBUNGAN DENGAN PENUGASAN KERJA**

**JUDUL PEMBELAJARAN: ________**

**Oleh: ________ *(tenaga ahli)***

## I. Rincian Penugasan Kerja

| Nama Pengguna Langsung / Pemberi Kerja | :  |
| --- | --- |
| Penempatan | : Proyek / Manajerial (kantor) |
| Nama Paket Pekerjaan (bila di proyek) | :  |
| Alamat Penugasan Kerja | :  |
| Waktu Pelaksanaan | : ________ hingga ________ |
| Posisi Penugasan | :  |
| Judul Pembelajaran | :  |

## II. Uraian Tugas Pekerjaan

*Memuat ringkasan uraian penugasan berupa pokok pekerjaan yang dilakukan.*

<aside>
💡

Contoh (proyek jalan tol): identifikasi risiko sejak awal proyek · komunikasikan risiko dengan seluruh project stakeholder · pertimbangkan positive & negative risk · penilaian risiko sebelum memecahkannya · rencanakan respon risiko yang tepat · rencanakan tindakan pencegahan · persiapkan rencana darurat.

</aside>

1. 
2. 
3. 

## III. Target Pengembangan Keahlian

*Memuat target pengembangan keahlian atau kemampuan yang hendak dicapai setelah melakukan pembelajaran.*

<aside>
💡

Contoh: (1) lebih memahami penerapan ISO 31000 Risk Management – Principles and Guidelines; (2) mampu melaksanakan kerangka manajemen risiko organisasi (ERM) hingga level 5.

</aside>

1. 
2. 

## IV. Pembelajaran Sehubungan dengan Penugasan Kerja

*Memuat ringkasan hal-hal yang dipelajari dalam pelaksanaan pekerjaan, dijabarkan dalam beberapa sub bagian. Setiap sub bagian berisi penjelasan substansi yang ditemui dan dipelajari.*

### 1. [Sub bagian pembelajaran]

*(Penjelasan terkait substansi yang ditemui dan dipelajari)*

### 2. [Sub bagian pembelajaran]

*(Penjelasan terkait substansi yang ditemui dan dipelajari)*

### 3. [Sub bagian pembelajaran]

*(Penjelasan terkait substansi yang ditemui dan dipelajari)*

---

## Tambahan SIGAP (di luar format SE — pendukung penilaian)

### Panduan isi per sub bagian (STAR + Impact + Refleksi)

- Situation — konteks proyek/kegiatan, waktu, tempat
- Task — peran dan tanggung jawab pribadi
- Action — metode, keputusan, alat yang dipakai
- Result — hasil terukur (angka, %, waktu, biaya, mutu, K3)
- Impact — dampak bagi proyek/organisasi
- Refleksi — apa yang dipelajari dan kaitannya dengan unit kompetensi jabker (SK DJBK 114/2024)

### Varian Pembelajaran Mandiri (Mode B — webinar, modul, buku, video)

Ganti Bab I dengan identitas sumber belajar (judul, penyelenggara/penulis, tanggal, JP, tautan). Bab II–IV tetap: ringkasan materi, target keahlian, pembelajaran & penerapan. Tambahkan pertanyaan & jawaban pemahaman.

### Lampiran Bukti

- [ ]  Kontrak kerja / surat referensi / surat tugas (wajib untuk penugasan kerja)
- [ ]  Dokumen pendukung (foto, laporan, risk register, BAST, dsb.)
- [ ]  Sertifikat/bukti kehadiran (untuk pembelajaran mandiri)
- [ ]  Dicatat di buku catatan elektronik SIJK

### Pernyataan Keaslian

Saya menyatakan ringkasan eksekutif ini disusun berdasarkan pekerjaan/pembelajaran yang benar-benar saya lakukan, dan seluruh data dapat dipertanggungjawabkan.

Tanda tangan & tanggal: